﻿namespace Models;

public class EmailViewModel
{
    public string Email { get; set; }
}