﻿namespace Emails;

public class Helper
{
    public const string DefaultStyle = "font-size: 14px";
}